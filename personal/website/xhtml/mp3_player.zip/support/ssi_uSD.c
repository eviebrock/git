#include "inc/lm3s1968.h"
#include "inc/hw_types.h"

#include "ssi_uSD.h"

// base address for bit-banged SSI0_SR_R register
#define SSI0_SR_BIT_BASE ((volatile unsigned long *)(0x42000000 | 0x800C*32))

// locations of bits relative to the base
#define SSI0_SR_BSY SSI0_SR_BIT_BASE[4]         // SSI BUSY
#define SSI0_SR_RNE SSI0_SR_BIT_BASE[2]         // Rx FIFO Not Empty
#define SSI0_SR_TNF SSI0_SR_BIT_BASE[1]         // Tx FIFO Not Full
#define fastvalue 4								// Fast value prescale for SSI0clockSpeed function, 12.5 MHz
#define slowvalue 180							// Slow value prescale for SSI0clockSpeed function, 400 KHz

// Initialize and enable the SSI module
void SSI0init( void )
{

	volatile unsigned long ulLoop;

	SYSCTL_RCGC1_R |= SYSCTL_RCGC1_SSI0;		// Set SSI0 bit in RCGC1 register
	ulLoop = SYSCTL_RCGC2_R;
	SSI0_CR1_R &= ~SSI_CR1_SSE;					// Disable SSE bit in SSICR1 register
	SSI0_CR1_R &= ~SSI_CR1_MS;					// Set SSICR1 register to "master"
	SSI0_CPSR_R &= ~SSI_CPSR_CPSDVSR_M;			// Mask clock prescale divisor bits
	SSI0_CPSR_R |= 0x06;						// Set clock prescale divisor value
	SSI0_CPSR_R &= ~SSI_CR0_SCR_M;				// Mask serial clock rate bits
	SSI0_CPSR_R |= 0x1400;						// Set serial clock rate value
	SSI0_CR0_R |= SSI_CR0_SPH;					// Write clock phase (SPH)
	SSI0_CR0_R |= SSI_CR0_SPO;					// Write clock polarity (SPO)
	SSI0_CR0_R &= ~SSI_CR0_FRF_M;				// Clear Frame Format Select bits
	SSI0_CR0_R |= SSI_CR0_FRF_MOTO;				// Sets SSI0 protocol mode to Freescale/Motorola frame format
	SSI0_CR0_R &= ~SSI_CR0_DSS_M;				// Clear Data Size Select bits
	SSI0_CR0_R |= SSI_CR0_DSS_8;				// Set SSI0 to 8-bit data
	SSI0_CR1_R |= SSI_CR1_SSE;					// Enable SSI by setting SSE bit in SSICR1

	SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA;		// Enables PORTA
	SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOG;		// Enables PORTG
	ulLoop = SYSCTL_RCGC2_R;
	// SSICLK
	GPIO_PORTA_DIR_R |= 0x04;					// Configures PA2 as output
	GPIO_PORTA_DEN_R |= 0x04;					// Enables PA2
	GPIO_PORTA_AFSEL_R |= 0x04;					// Alternate function
	// SSI0 Rx
	GPIO_PORTA_DIR_R &= ~0x10;					// Configures PA4 as input
	GPIO_PORTA_DEN_R |= 0x10;					// Enables PA4
	GPIO_PORTA_AFSEL_R |= 0x10;					// Alternate function
	// SSI0 Tx
	GPIO_PORTA_DIR_R |= 0x20;					// Configures PA5 as output
	GPIO_PORTA_DEN_R |= 0x20;					// Enables PA5
	GPIO_PORTA_AFSEL_R |= 0x20;					// Alternate function
	// CD
	GPIO_PORTA_DIR_R &= ~0x40;					// Configures PA6 as input
	GPIO_PORTA_DEN_R |= 0x40;					// Enables PA6
	GPIO_PORTA_PUR_R |= 0x40;					// Pull Up

	// CS
	GPIO_PORTA_DIR_R |= 0x80;					// Configures PA7 as output
	GPIO_PORTA_DEN_R |= 0x80;					// Enables PA7
	GPIO_PORTA_PUR_R |= 0x80;					// Pull Up

	//CS
	//SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOG;		// Enables PORTG
	//ulLoop = SYSCTL_RCGC2_R;					// Delay while enabling port

	GPIO_PORTG_DIR_R |= 0x80;					// Configures PG7 as output
	GPIO_PORTG_DEN_R |= 0x80;					// Enables PG7
	GPIO_PORTG_PUR_R |= 0x80;					// Pull Up
}

// Set the prescaler. The calculation for the correct values are shown
// in the datasheets.  The slow value should give ~400KHz, the fast value
// in the range 10-15MHz.



void SSI0clockSpeed( uint8_t spd ) {
  switch (spd) {
  case SPI_FAST:
	SSI0_CPSR_R &= ~SSI_CPSR_CPSDVSR_M;			// Masks register
    SSI0_CPSR_R = fastvalue;					// Sets fastvalue
    break;
  case SPI_SLOW:
	SSI0_CPSR_R &= ~SSI_CPSR_CPSDVSR_M;			// Masks register
    SSI0_CPSR_R = slowvalue;					// Sets slowvalue
    break;
  default:
    break;
  }
}

// Assert the CS signal, active low (CS=0)
void SSI0CSassert( void )
{
	GPIO_PORTA_DATA_R &= ~0x80;					// Clearing data for PA7, sets CS pin low
	// GPIO_PORTG_DATA_R &= ~0x80;				// Clearing data for PG7, sets CS pin low
}

// Deassert the CS signal (CS=1)
void SSI0CSdeassert( void )
{
	while (SSI0_SR_BSY);  						// wait until room in FIFO, wait until SSI is not busy
	GPIO_PORTA_DATA_R |= 0x80;					// Setting PA7 high, sets CS pin high
	// GPIO_PORTG_DATA_R |= 0x80;				// Setting PG7 high, sets CS pin high
}

// Send a single byte over the SPI port
void SSI0TxByte( uint8_t data )
{
	// transmit one byte of data over SSI interface
	// wait until the transfer is completed, then read and
	// discard the byte received from the slave

	volatile unsigned short receive;			// hold data while in scope

	while ( SSI0_SR_TNF == 0);					// wait until room in FIFO
	SSI0_DR_R = data;							// transmit data
	while ( SSI0_SR_RNE == 0);					// wait while RX FIFO empty

	receive = SSI0_DR_R;						// receive from slave
}

// Receive a byte. Send an 0xFF (the bus idles high) to receive the byte
uint8_t SSI0RxByte( void ) {

	while ( SSI0_SR_TNF == 0 );					// wait until room in FIFO
	SSI0_DR_R = 0xFF;							// transmit data
	while ( SSI0_SR_RNE == 0 );					// wait while RX FIFO empty

	return SSI0_DR_R;							// receive from slave
}

void SSI0RxBuffer(uint16_t len, uint8_t *buffer) {
	SSI0CSassert();								// select device
	// since we wait for each byte to be transferred, we can't overfill the TX
	// FIFO.  only do the wait once to make sure there's room (there always should
	// be).

	while ( SSI0_SR_TNF == 0 );					// wait until room in FIFO
	while ( len ) {
		SSI0_DR_R = 0xff;						// trade bytes transfer
	while ( SSI0_SR_RNE == 0 );					// wait while RX FIFO empty
		*buffer++ = SSI0_DR_R;
		--len;
	}
	SSI0CSdeassert();							// deselect device
}

// return the status of the CD pin
uint8_t SSI0readCD( void ) {
	return GPIO_PORTA_DATA_R & 0x40;
}
