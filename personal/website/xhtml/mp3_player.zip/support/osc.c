#include "inc/lm3s1968.h"

int mainOscInit(void) {
	// step 1
	SYSCTL_RCC_R |= SYSCTL_RCC_BYPASS;	// set bypass to high
	SYSCTL_RCC_R &= ~SYSCTL_RCC_USESYSDIV;	// set usesysdiv to low

	// step 2
	SYSCTL_RCC_R &= ~SYSCTL_RCC_XTAL_M;	// clear crystal value
	SYSCTL_RCC_R |= SYSCTL_RCC_XTAL_8MHZ;	// set crystal value to 8 MHz
	SYSCTL_RCC_R &= ~SYSCTL_RCC_OSCSRC_M;	// clear oscsrc
	SYSCTL_RCC_R |= SYSCTL_RCC_OSCSRC_MAIN;	// sets oscsrc
	SYSCTL_RCC_R &= ~SYSCTL_RCC_PWRDN;	// set power down bit low

	// step 3
	SYSCTL_RCC_R &= ~SYSCTL_RCC_SYSDIV_M;	// clear sysdiv
	SYSCTL_RCC_R |= SYSCTL_RCC_SYSDIV_4;	// divided clock by 4
	SYSCTL_RCC_R |= SYSCTL_RCC_USESYSDIV;	// set to high

	// step 4
	while (!(SYSCTL_RIS_R & SYSCTL_RIS_PLLLRIS))
	{
		// do nothing
	}

	// step 5
	SYSCTL_RCC_R &= ~SYSCTL_RCC_BYPASS;	// clear bypass

	return 0;
}
