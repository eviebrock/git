#ifndef SSI_UCD_H
#define SSI_UCD_H
#include <stdint.h>
#include <ctype.h>

enum SSI0speed_t {
  SPI_SLOW = 0,         // set clock for SPI initialization
  SPI_FAST = 1          // set clock for max SD transfer rate
};

void SSI0init( void );
void SSI0clockSpeed( uint8_t );
void SSI0CSassert( void );
void SSI0CSdeassert( void );
void SSI0TxByte( uint8_t );
uint8_t SSI0RxByte( void );
void SSI0RxBuffer(uint16_t, uint8_t*);
uint8_t SSI0readCD( void );

#endif  // SSI_UCD_H
