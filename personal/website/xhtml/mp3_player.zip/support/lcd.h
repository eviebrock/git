#ifndef LCD_H
#define LCD_H

#include <stdint.h>

void lcdInit (void);
void lcdWriteChr ( uint8_t chr );
void lcdWriteStr ( uint8_t *str );
void lcdCursorPos ( uint8_t row, uint8_t col );
void lcdCursorMode ( uint8_t mode );
void lcdClear ();

#endif
