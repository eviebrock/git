#ifndef PS2_H
#define PS2_H

#include <stdint.h>

void PS2Init();
uint8_t PS2Check();

#endif
