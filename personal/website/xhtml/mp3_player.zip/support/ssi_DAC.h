#ifndef SSI_DAC_H
#define SSI_DAC_H

#include <stdint.h>

void SSI1Init(void);
void SSI1TxData( uint8_t dac, uint16_t data );

#endif
