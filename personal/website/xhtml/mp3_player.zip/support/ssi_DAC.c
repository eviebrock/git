#include <stdint.h>
#include "inc/lm3s1968.h"

void SSI1Init(void)
{
	/*
	this procedure initializes the SSI1 module, similar to SSI0Init() last
	week. You will determine most of the settings for this module based on the values in the
	AD5322 datasheet. You should configure it to transmit as fast as possible to the AD5322.
	*/
	volatile unsigned long ulLoop;

	SYSCTL_RCGC1_R |= SYSCTL_RCGC1_SSI1;		// Set SSI1 bit in RCGC1 register
	ulLoop = SYSCTL_RCGC2_R;
	SSI1_CR1_R &= ~SSI_CR1_SSE;					// Disable SSE bit in SSICR1 register
	SSI1_CR1_R &= ~SSI_CR1_MS;					// Set SSICR1 register to "master"
	SSI1_CPSR_R &= ~SSI_CPSR_CPSDVSR_M;			// Mask clock prescale divisor bits

	// different
	//SSI1_CPSR_R |= 0x02;						// Set clock prescale divisor value, 50 MHz/2 = 25 MHz < 30 MHz
	SSI1_CPSR_R |= 0x04;
	SSI1_CPSR_R &= ~SSI_CR0_SCR_M;				// Mask serial clock rate bits
	SSI1_CPSR_R |= 0x00;						// Set serial clock rate value

	SSI1_CR1_R |= SSI_CR0_SPH;					// Write clock phase (SPH)
	SSI1_CR1_R |= SSI_CR0_SPO;					// Write clock polarity (SPO)
	SSI1_CR1_R &= ~SSI_CR0_FRF_M;				// Clear Frame Format Select bits

	// not here
	SSI1_CR1_R |= SSI_CR0_FRF_MOTO;				// Sets SSI1 protocol mode to Freescale/Motorola frame format
	SSI1_CR1_R &= ~SSI_CR0_DSS_M;				// Clear Data Size Select bits

	SSI1_CR1_R |= SSI_CR0_DSS_16;				// Set SSI1 to 16-bit data
	SSI1_CR1_R |= SSI_CR1_SSE;					// Enable SSI by setting SSE bit in SSICR1
}

void SSI1TxData(uint8_t dac, uint16_t data)
{
	/*
	this procedure takes a 16-bit unsigned value
	and sends to one of the DACs. When dac is 0 data is sent to the �left� DAC, and when it is 1
	data is sent to the �right� DAC. The convention will be that the �left� DAC is DAC A so all
	lab groups ends up with similar circuitry and code.
	*/
	volatile unsigned short send;
	// Send data to the left DAC, "DAC A"
	if (dac == 0)
		data &= ~0x8000;

	// Send data to the right DAC
	else
		data |= 0x8000;

	SSI1_DR_R = data;
}


