#ifndef OSC_H
#define OSC_H

#include <stdint.h>

int mainOscInit(void);

#endif
