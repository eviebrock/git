#ifndef RIFF_H
#define RIFF_H

#include <stdint.h>

typedef uint16_t u16;   // use the types provided in the RIFF documentation
typedef uint32_t u32;


typedef struct {
  u32 ChunkID;          // Contains the letters "RIFF" in ASCII form
                        //     (0x52494646 big-endian form).
  // unsigned char ChunkSize[4];        // 4 + (8 + SubChunk1Size) + (8 + SubChunk2Size)
  u32 ChunkSize;        // 4 + (8 + SubChunk1Size) + (8 + SubChunk2Size)
                        // This is the size of the rest of the chunk 
                        // following this number.  This is the size of the 
                        // entire file in bytes minus 8 bytes for the
                        // two fields not included in this count:
                        // ChunkID and ChunkSize.
  u32 Format;           // Contains the letters "WAVE"
                        // (0x57415645 big-endian form).

// The "WAVE" format consists of two subchunks: "fmt " and "data":
// The "fmt " subchunk describes the sound data's format:

  u32 Subchunk1ID;      // Contains the letters "fmt "
                        //     (0x666d7420 big-endian form).
  u32 Subchunk1Size;    // 16 for PCM.  This is the size of the
                        // rest of the Subchunk which follows this number.
  u16 AudioFormat;      // PCM = 1 (i.e. Linear quantization)
                        // Values other than 1 indicate some 
                        // form of compression.
  u16 NumChannels;      // Mono = 1, Stereo = 2, etc.
  u32 SampleRate;       // 8000, 44100, etc.
  u32 ByteRate;         // == SampleRate * NumChannels * BitsPerSample/8
  u16 BlockAlign;       // == NumChannels * BitsPerSample/8
                        //    The number of bytes for one sample including
                        //    all channels. I wonder what happens when
                        //    this number isn't an integer?
  u16 BitsPerSample;    // 8 bits = 8, 16 bits = 16, etc.

// The "data" subchunk contains the size of the data and the actual sound:

  u32 Subchunk2ID;      // Contains the letters "data"
                        //     (0x64617461 big-endian form).
  u32 Subchunk2Size;    // == NumSamples * NumChannels * BitsPerSample/8
                        //    This is the number of bytes in the data.
                        //    You can also think of this as the size
                        //    of the read of the subchunk following this 
                        //    number.
} RIFFheader;

#endif
