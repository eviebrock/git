
// Initializes the bit banging SPI code.  It configures Port G for I/O
// and set up Timer 0A to generate an interrupt which will send a value
// out over Port G.  The value output in incremented by one each time.
// NOTE: the timer is not started by this procedure: you will need to
// call bbStart() to start the transmission.

void initBBSPI(void);

// Turns on Timer 0A to start the bit-banging demo.

void bbStart(void);

// Turns off Timer 0A.  This is useful so that when your code is running, it
// is not interrupted by the demo code.

void bbStop(void);
