#define PART_LM3S1968
#include "inc/lm3s1968.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <ctype.h>

#include "ssi_DAC.h"
#include "microSD.h"
#include "riff.h"
#include "lcd.h"

#define BUFSIZE 512

volatile char soundOut_identifier[] = "HUGHES-soundOut.c";

#define ID3             0x40 // size of name/song strings
#define RIFFHEADER      sizeof(RIFFheader) // size of RIFF header
#define STARTSOUND		416

// from RIFF header
uint32_t sector;
uint16_t rate;
uint8_t channels;
uint32_t size;
uint32_t totalSize;

// DAC code for outputting sound
const uint16_t BUFFERSIZE = BUFSIZE*2;
static uint8_t soundBuffer[BUFSIZE*2];
static uint8_t lvolume = 8;
static uint8_t rvolume = 8;
static uint8_t speed = 1;

// added for interrupts
static int bufferIndex = 0;		// index in sound buffer of byte that was just played
static int flagA = 1;			// flag that is set to 1 when the first half of the sound buffer is finished playing and data can be written to it
static int flagB = 1;			// flag that is set to 1 when the second half of the sound buffer is finished playing and data can be written to it
static int byteCounter;			// total byte count of current song that has been played

// for writing to LCD
char textToDisplay[32];
static uint8_t artistName[32];
static uint8_t songTitle[32];

void SSI1TxData(uint8_t dac, uint16_t data);
void timer1AInit(int songFrequency);

void soundVolume(int8_t vol)
{
	if (vol == 1)
	{
		if(lvolume < 15 && rvolume < 15)
		{
			++lvolume;
			++rvolume;
		}
	}

	else if (vol == -1)
	{
		if(lvolume > 0 && rvolume > 0)
		{
		  --lvolume;
		  --rvolume;
		}
	}
}

void soundBalance(int8_t bal)
{
	if (bal == 1)
	{
		if ( lvolume > 0 && rvolume < 15)
		{
			--lvolume;
			++rvolume;
		}
	}

	else if (bal == -1)
	{
		if ( rvolume > 0 && lvolume < 15)
		{
			--rvolume;
			++lvolume;
		}
	}
}

void soundInit()
{
	SSI1Init();
	// set initial volume level
	lvolume = rvolume = 8;
}

// alter between displaying artist/title on the LCD and displaying frequency/channel information
void changeDisplay(int displayMode, int songNumber, int isPlaying)
{
	lcdClear();

	// display artist/title on LCD
	if (displayMode == 0)
	{
		// output the song number on first line
		lcdCursorPos (0, 0);
		sprintf(textToDisplay, "%i. ", (songNumber-1));
		lcdWriteStr(textToDisplay);

		// output the artist name
		lcdWriteStr(artistName);

		// output whether the song is playing (O) or is paused (X) on the second line
		lcdCursorPos(1, 0);
		if (isPlaying == 1)
			lcdWriteStr("O- ");
		else
			lcdWriteStr("X- ");

		// output the song name
		lcdWriteStr(songTitle);
	}

	// display frequency/channel information on LCD
	else if (displayMode == 1)
	{
		// output song frequency on first line
		lcdCursorPos(0, 0);
		sprintf(textToDisplay, "FREQ: %d Hz", rate);
		lcdWriteStr(textToDisplay);

		// output channel configuration on second line
		lcdCursorPos(1, 0);
		if (channels == 1)
			lcdWriteStr("CHANNEL: MONO");
		else
			lcdWriteStr("CHANNEL: STEREO");
	}
}

// display configuration information such as the balance and whether or not the MP3 player is in shuffle/sequential mode
void displayConfig(int shuffle)
{
	lcdClear();

	// output the left and right volumes on on first line
	lcdCursorPos (0, 0);
	sprintf(textToDisplay, "LVol:%d ", lvolume);
	lcdWriteStr(textToDisplay);
	sprintf(textToDisplay, "RVol:%d ", rvolume);
	lcdWriteStr(textToDisplay);

	// output whether in sequential or shuffle mode on the second line
	lcdCursorPos (1, 0);
	if (shuffle == 0)
		lcdWriteStr("SEQUENTIAL");
	else
		lcdWriteStr("SHUFFLE");
}

// increase the speed playing at by decreasing the interval load value of timer 1A
void increaseSpeed(void)
{
	int coreFrequency = 50000000;	// of microcontroller (Hz)

	// prevent speed from exceeding 8x normal speed
	if (speed < 8)
		speed += 1;

	TIMER1_CTL_R &= ~TIMER_CTL_TAEN;				// clear Timer A Enable bit in GPTM Control Register to disable timer during re-initialization

	int interval = coreFrequency/ (rate * speed);	// time interval for timer now divided
	TIMER1_TAILR_R = interval;						// set GPTM Timer A Interval Load Register with time interval

	TIMER1_CTL_R |= TIMER_CTL_TAEN;					// set Timer A Enable bit in GPTM Control Register to re-enable
}

bool startPlaying( uint32_t block )
{
	int songTitleOffset = 32;

	RIFFheader  *header = (RIFFheader  *)(soundBuffer+ID3);

	// save first block of file
	sector = block;

	// clear the LCD while we're reading the header
	lcdClear();

	// read header from file
	if ( !microSDRead (block, soundBuffer) ) return false;

	// determine file size in kBytes for display, and number of blocks to read
	size = header->Subchunk2Size;
	totalSize = size;

	// set up DAC, figure out block skip size
	channels = header->NumChannels;

	//  dacstereo( channels-1 );
	rate = header->SampleRate;

	memcpy(artistName, soundBuffer, 32);					// copy 32 bytes of artist name for later
	memcpy(songTitle, soundBuffer + songTitleOffset, 32);	// copy 32 bytes of song title for later

	// turn off timer (reading the register also clears COUNT bit
	NVIC_ST_CTRL_R &= ~NVIC_ST_CTRL_ENABLE;

	// set up the desired reload frequency
	NVIC_ST_RELOAD_R = 50000000 / rate;

	// set the external clock source and enable the timer
	NVIC_ST_CTRL_R = NVIC_ST_CTRL_CLK_SRC | NVIC_ST_CTRL_ENABLE;

	// start sound interrupt and reset playing song global variables
	timer1AInit(rate);
	bufferIndex = STARTSOUND;
	flagA = 1;
	flagB = 1;
	byteCounter = 0;

	// start playing first block
	size -= BUFSIZE-(ID3+RIFFHEADER);

	return true;
}

// interrupt handler used to send sound to the DAC
void soundHandler(void)
{
	byteCounter++;

	// always send to the left channel
	SSI1TxData(0, soundBuffer[bufferIndex] * lvolume);

	bufferIndex++;

	// if mono, send the same byte to the right channel
	if (channels == 1)
		SSI1TxData(1, soundBuffer[bufferIndex] * rvolume);

	// if stereo, send the next byte to the right channel
	else
	{
		SSI1TxData(1, soundBuffer[bufferIndex] * rvolume);
		bufferIndex++;
		byteCounter++;
	}

	bufferIndex %= (BUFSIZE*2);				// avoid bufferIndex being greater than size of buffer (1024 bytes)

	if (bufferIndex == 512)
		flagA = 1;

	else
		flagA = 0;

	if (bufferIndex == 0)
		flagB = 1;

	else
		flagB = 0;

	TIMER1_ICR_R |= TIMER_ICR_TATOCINT;
}

// read from micro-sd card and write to buffer when not being interrupted
bool keepPlaying(void)
{
	// first half of buffer is read and data can be written to it
	if (flagA)
	{
		++sector;		// go to next sector

		// if read fails, signal EOF
		if (!microSDRead (sector, soundBuffer))
		{
			// disable interrupt
			TIMER1_IMR_R &= ~TIMER_IMR_TATOIM;			// clear TATOIM bit in GPTM Interrupt Mask Register to disable interrupts
			TIMER1_CTL_R &= ~TIMER_CTL_TAEN;			// clear Timer A Enable bit in GPTM Control Register to disable timer
			TIMER1_ICR_R &= ~TIMER_ICR_TATOCINT;		// clear TATOCINT bit in Interrupt Clear Register for resetting

			return false;
		}

		else
			return true;
	}

	// second half of buffer is read and data can be written to it
	if (flagB)
	{
		++sector;		// go to next sector

		if (!microSDRead (sector, &soundBuffer[512]))
		{
			// disable interrupt
			TIMER1_CTL_R &= ~TIMER_CTL_TAEN;		// clear Timer A Enable bit in GPTM Control Register to disable timer

			return false;
		}

		else
			return true;
	}

	return true;
}

uint16_t getRate(void)              // sample rate
{
   return rate;
}

uint8_t getChannels(void)           // number of channels (0 or 1)
{
   return channels;
}
