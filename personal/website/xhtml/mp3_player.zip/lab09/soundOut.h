#ifndef SOUNDOUT_H
#define SOUNDOUT_H

#include <stdint.h>
#include <stdbool.h>

void soundInit(void);
bool startPlaying(uint32_t sector);
bool keepPlaying(void);
void soundVolume(int8_t vol);
void soundBalance(int8_t bal);
uint16_t getRate(void);
uint8_t getChannels(void);
void soundFIFO(void);
void changeDisplay(int displayMode, int songNumber, int isPlaying);
void displayConfig(int shuffle);
void increaseSpeed(void);

#endif
