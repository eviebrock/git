// Labs 9-10
// Description:
//
// Music is played in this project via an interrupt that is controlled by timer 1A. This code constantly
// attempts to write to either half a 1024 byte buffer. Whenever either half of the buffer is finished
// being written to, the other half of the buffer will be attempted to be written to. Meanwhile, Timer 1A
// counts down from an interval that is determined by dividing the internal 50 MHz clock by the frequency
// of each specific song. Each time timer 1A counts down, the interrupt handler attempts to send data to
// the DAC to play sound. Which half of the 1024 byte buffer to read from is alternated and sent on time
// via that timed interrupt to help avoid gaps. Status flags are used to ensure that data is not written
// to the buffer until the data from that half of the buffer has already been sent to the DAC. The code
// checks for an inputed character from the PS/2 keyboard each time it iterates through an infinite while
// loop in main. When a key with a certain functionality is pressed, that functionality is triggered in
// a certain if or else if statement in that loop. The mode of the MP3 player can be either sequential or
// shuffle. In sequential mode, the original order of the array with sector byte numbers is left alone so
// that songs are played in the order on the Micro-SD card. When switched to shuffle mode, that array is
// shuffled so that the song orders are swapped by a random shuffling function. Stopping and pausing the
// songs requires disabling interrupts and entering infinite loops. Jumping forward and backward in a song
// requires incrementing and decrementing the current sector being read, respectively. The amount of bytes
// to skip by can be calculated from song frequency and the amount of seconds to skip by. The size left to
// read must also be decreased when skipping forward and increased when skipping backward. The speed a song
// plays at can be sped up by cutting the reload value for timer 1A. Writing to the LCD is mainly done via
// functions in soundOut.c. changeDisplay is used to alter between displaying artist/title on the LCD and
// displaying frequency/channel information. displayConfig is used to display configuration information
// such as the balance and whether or not the MP3 player is in shuffle/sequential mode.

#include "inc/lm3s1968.h"
#include <stdint.h>
#include <stdlib.h>

#include "ssi_uSD.h"
#include "microSD.h"
#include "readdir.h"
#include "soundOut.h"

void mainOscInit(void);
void uartInit();
uint16_t uartRead();
void PS2Init();
uint8_t PS2Check();
void lcdInit();
void lcdClear();
void setT1AFuncPtr(void (*FuncPtr)(void));
void soundHandler(void);
void timer1AInit(int songFrequency);
void lcdWriteStr (uint8_t *str);
void lcdCursorPos (uint8_t row, uint8_t col);

// variables accessed from soundout.c
extern uint32_t sector;
extern uint16_t rate;
extern uint8_t channels;
extern uint32_t size;
extern uint32_t totalSize;

static uint32_t songSectors[14];	// storage for 16 song starting sectors

int main()
 {
	uint8_t i, count;
	double bytesPerSector = 512;
	double jumpSize = 0;			// jump size in sectors, used for jumping forward or backward in a song
	int shuffle = 0;				// set to 0 for default sequential mode, set to 1 for shuffle mode
	int index = 0;					// index used for changing song order when swapping between shuffle mode and sequential mode
	int mode = 0;					// set to 0 for displaying artist/title on LCD, set to 1 for displaying frequency/channel on LCD
	uint32_t block;

	mainOscInit();					// set the system clock to 50MHz
	SSI0init();						// initialize the SSI0 hardware
	soundInit();					// initialize SSI1 and sound module
	PS2Init();						// initialize UART and PS/2 module
	lcdInit();						// initialize LCD

	// infinite loop
	while (1)
	{
		// handle when microSD card is not detected and wait for insertion
		if (!SSI0readCD())
		{
			int tyree = 0;		// used for delay

			// instruct user to insert micro-sd card
			lcdClear();
			lcdWriteStr("INSERT");
			lcdCursorPos(1,0);
			lcdWriteStr("MICRO-SD CARD");

			while (!SSI0readCD());		// wait until SD card is inserted

			tyree += 3;	// delay after read
		}

		while (!microSDInit());			// loop until the micro SD card initializes successfully

		count = readdir(songSectors);	// read the directory

		// play each song
		i = 0;
		while (1)
		{
			// move to next song if no bytes left to play
			if (count == 0)
				break;

			block = songSectors[i];
			i++;

			// if it starts successfully
			if (startPlaying(block))
			{
				mode = 0;						// set to sequential mode
				changeDisplay(mode, i, 1);		// display current LCD configuration

				// play until the end of a song
				while (keepPlaying())
				{
					uint8_t chr = PS2Check();

					// skip to song
					if (chr >= '0' && chr <= '9')
					{
						i = chr-'0';	// if number pressed, skip to that song
						break;
					}

					// stop song
					else if (chr == 'X' || chr == 'x')
					{
						TIMER1_CTL_R &= ~TIMER_CTL_TAEN;		// clear Timer A Enable bit in GPTM Control Register to disable timer for sound interrupt

						lcdClear();
						lcdWriteStr("STOPPED");

						// stop song from playing until a space bar is detected
						while (chr != ' ')
						{
							chr = PS2Check();
						}

						i--;	// decrement i to restart song after space bar is detected

						break;
					}

					// pause song
					else if (chr == ' ')
					{
						chr = 'a';	// arbitrary character that is not a ' '

						TIMER1_CTL_R &= ~TIMER_CTL_TAEN;		// clear Timer A Enable bit in GPTM Control Register to disable timer for sound interrupt

						changeDisplay(0, i, 0);					// display that the song is paused with an X

						// while loop that stops song from playing until a new space is detected
						while (chr != ' ')
						{
							chr = PS2Check();
						}

						changeDisplay(0, i, 1);					// display that the song is playing again with an O

						TIMER1_CTL_R |= TIMER_CTL_TAEN;			// set Timer A Enable bit in GPTM Control Register to enable timer for sound interrupt
					}

					// advance to next/last song
					else if (chr == 'N' || chr == 'n' || chr == 'L' || chr == 'l')
					{
						// advance to next song if N/n is detected
						if (chr == 'N' || chr == 'n')
						{
							if (i == count)
								i = 0;			// reset next song to 0 when playing the last song

							break;
						}

						// advance to last song if L/l is detected
						else
						{
							if (i == 1)
								i = count - 1;		// reset count if last is pressed when song 0 is being played
							else
								i = i - 2;			// decrement song number by 2 to move to the previous song otherwise

							break;
						}
					}

					// adjust volume
					else if (chr == '+' || chr == '-')
					{
						// increase volume if a + is detected
						if (chr == '+')
							soundVolume(1);

						// decrease volume if a - is detected
						else
							soundVolume(-1);

						displayConfig(shuffle);	// show new configuration
					}

					// adjust balance
					else if (chr == '>' || chr == '<')
					{
						// shift balance to right if a > is detected
						if (chr == '>')
							soundBalance(1);

						// shift balance to left if a < is detected
						else
							soundBalance(-1);

						displayConfig(shuffle);	// show new configuration
					}

					// jump forward or backward in a song
					else if (chr == 'F' || chr == 'f' || chr == 'B' || chr == 'b')
					{
						jumpSize = (5 / (bytesPerSector / rate)) * channels;		// determine jump size for jumping 5 seconds at a given rate, number of channels, and 512 bytes/sector

						// jump forward if an F or f is detected
						if (chr == 'F' || chr == 'f')
						{
							// advance to next song if within last 5 seconds of song
							if ((size - (jumpSize * bytesPerSector)) < 0)
							{
								if (i == count)
									i = 0;			// reset next song to 0 if playing the last song
								break;
							}

							// otherwise move forward 5 seconds in song
							else
							{
								size -= (jumpSize * bytesPerSector);		// decrease the amount of bytes left to play
								sector += jumpSize;
							}
						}

						// jump backward if a B or b is detected
						if (chr == 'B' || chr == 'b')
						{
							// restart song if within first 5 seconds of song
							if ((size + (jumpSize * bytesPerSector)) > totalSize)
							{
								i--;
								break;
							}

							// otherwise move backward 5 seconds in song
							else
							{
								size += (jumpSize * bytesPerSector);		// increase the amount of bytes left to play
								sector -= jumpSize;
							}
						}
					}

					// switch between sequential and shuffle
					else if (chr == 'R' || chr == 'r')
					{
						// switch to sequential mode if currently in shuffle mode and change song order to sequential order
						if (shuffle == 1)
						{
							shuffle = 0;

							count = readdir(songSectors);	// read the directory and change song order to sequential order

							i = 0;							// change to first song on track
							break;
						}

						// switch to shuffle mode if currently in sequential mode and shuffle song order
						else
						{
							shuffle = 1;			// switch to shuffle mode

							// shuffle song order
							for (index = 0; index < count; index++)
							{
								int randomIndex = rand() % count;	// get a random index in total songs

								// swap song numbers in indices index and randomIndex
								int temp = songSectors[randomIndex];
								songSectors[randomIndex] = songSectors[index];
								songSectors[index] = temp;
							}

							i = songSectors[0];				// change to first song on shuffled track
							break;
						}
					}

					// switch the LCD display mode between artist/title and frequency/channel information
					else if (chr == 'D' || chr == 'd')
					{
						// switch to displaying frequency/channel information
						if (mode == 0)
							mode = 1;

						// switch to displaying artist/title information
						else
							mode = 0;

						changeDisplay(mode, i, 1);
					}

					// display the user configuration information (volume setting, balance, sequential or shuffle)
					else if (chr == 'C' || chr == 'c')
					{
						displayConfig(shuffle);
					}

					// play the song at a faster speed
					else if (chr == 'S' || chr == 's')
					{
						increaseSpeed();
					}
				}

				// after last song, start over
				if (i > count)
					i = 0;
			}

			// break out of song gracefully if micro-sd card is removed during play
			if(!SSI0readCD())
				break;
		}
	}
}

void timer1AInit(int songFrequency)
{
	int coreFrequency = 50000000;				// of microcontroller (Hz)
	int interval = coreFrequency/songFrequency;	// time interval for timer

	SYSCTL_RCGC1_R |= SYSCTL_RCGC1_TIMER1;		// enable peripheral clock

	// waste time for peripheral clock
	volatile int wasteTime;
	wasteTime = 3;

	TIMER1_CTL_R &= ~TIMER_CTL_TAEN;			// clear Timer A Enable bit in GPTM Control Register to disable timer during initialization

	TIMER1_CFG_R &= ~TIMER_CFG_M;				// clear bits 0-2 in the GPTM Configuration Register before specifying the timer size
	TIMER1_CFG_R |= TIMER_CFG_32_BIT_TIMER; 	// write the GPTM Configuration Register with a value of 0x0 to specify a 32-bit timer (should already be cleared anyway)

	TIMER1_TAMR_R | TIMER_TAMR_TAMR_PERIOD;		// write a value of 0x2 to GPTM TIMERA Mode Register for periodic mode

	TIMER1_TAILR_R = interval;					// set GPTM Timer A Interval Load Register with time interval

	TIMER1_IMR_R |= TIMER_IMR_TATOIM;			// set TATOIM bit in GPTM Interrupt Mask Register to enable interrupts
	TIMER1_ICR_R |= TIMER_ICR_TATOCINT;			// set TATOCINT bit in GPTM Interrupt Clear Register to clear status flags for interrupt

	NVIC_EN0_R |= NVIC_EN0_INT21;				// enable interrupt 21 for Timer 1A
	setT1AFuncPtr(soundHandler);				// assign call-back function for Timer 1A interrupt

	NVIC_PRI5_R |= (1 << NVIC_PRI5_INT23_S);	// give priority 1 to LCD interrupt for lower priority than sound interrupt for optimal sound quality

	TIMER1_CTL_R |= TIMER_CTL_TAEN;				// set Timer A Enable bit in GPTM Control Register to enable timer
}
