#ifndef READDIR_H
#define READDIR_H

#include <stdint.h>

// read the directory and locate the starting sector for
// each sound file on the card;  returns the number of
// songs in the list

uint8_t readdir( uint32_t * songSector );

#endif  // READDIR_H
