// read the boot sector to find the data, FAT table
// find the directory, read file entries (maybe don't need a special file,
//   just locate .WAV files?), build "dir" of songs
// 
// to read a file:
//  find first FAT entry from file
//  compute sector with the FAT, read it
//  read sector from FAT
//

#include <stdint.h>
#include <string.h>

#include "microSD.h"

#define DIRENTRY_SIZE 	32	// size of a directory entry

uint8_t readdir( uint32_t * songSector )
{
  uint8_t numSongs = 0;
  static uint8_t buffer[512];
  uint32_t  SSA;
  uint8_t  spc;
  uint8_t i;
  // read root directory
  if ( !microSDRead (0, buffer) ) return 0;

  // get starting sector address
  SSA = 32 + (*((uint32_t *)(buffer + 0x24)) << 1);
  // get sectors per cluster
  spc = buffer[0x0d];

  // now read directory
  for(i = 0; i <= 4 ; i++) { 
    uint8_t *ptr = buffer;
    uint8_t  count = 512/DIRENTRY_SIZE;
    if ( !microSDRead( SSA+i, buffer ) ) return 0;
    while (count) {
      // if filename start with something printable, and attribute is archive,
      // and extension is WAV, calculate sector and store it
      if ( *ptr & 0x60 ) {
          if ( !strncmp( (const char *)(ptr+8), "WAV ",4) ) {
            uint32_t cluster = *(uint16_t *)(ptr + 0x14) << 16 |
            			*(uint16_t *)(ptr + 0x1A);
            *songSector++ = SSA + (cluster - 2) * spc;
            ++numSongs;
         }
      }
      ptr += DIRENTRY_SIZE;
      --count;
    }
  }
  return numSongs;
}

