#!/usr/bin/python3

# Usage:
#  ./download.py <URL-TO-DOWNLOAD>
#
# Example URLs:
#  http://www.google.com/images/srpr/logo3w.png
#  http://imgsrc.hubblesite.org/hu/db/images/hs-2006-01-a-800_wallpaper.jpg
#  http://www.hdscreenwallpapers.com/download/rockets-nasa-apollo-1280x800.jpg
#  http://imgsrc.hubblesite.org/hu/db/images/hs-2010-13-a-2560x1024_wallpaper.jpg
#  http://ut-images.s3.amazonaws.com/wp-content/uploads/2009/09/SED_wall_1920x1200.jpg

import string
import socket
import sys
import os
from subprocess import call
from urllib.parse import urlparse

# Size of receive buffer.
# Maximum number of bytes to get from network in one recv() call
max_recv = 64*1024

# Test input arguments to program
if len(sys.argv) != 2:
        sys.exit()

# Split URL into "host", "path", and "filename" variables.
o = urlparse(sys.argv[1])
host = o.netloc
path = os.path.dirname(o.path)
filename = os.path.basename(o.path)

port = 80

print("Preparing to download object from http://", host + path + filename)
print()

get = "GET "
http = " HTTP/1.1\nHost: "
slash = "/"
connect = "\nConnection: close"
car_ret = "\n\n"

full_request = get + path + slash + filename + http + host + connect + car_ret

print("Connecting to", host + ", port " + str(port))
print("Request to send to server:")
print("-------------------")
print(full_request)
print("-------------------")

# Connect to remote host
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host,port))

# Send request to remote host
s.sendall(bytes(full_request,'ascii'))

print("Receiving response from server")
response = s.recv(max_recv)
full_response = response
print("Got", len(response), 'bytes from recv()')

# Loop until we get 0 bytes from recv(), indicating server sent
# the entire object and then closed the socket when finished
while len(response) != 0:
    response = s.recv(max_recv)
    full_response = full_response + response
    print("Got", len(response), 'bytes from recv()')

# Close socket - done with network
s.close()

(header,data) = full_response.split(bytes("\r\n\r\n",'ascii'), 1)

# Convert the header from a byte array to a native python string
header = header.decode('ascii')

print("Header from server (omitting data):")
print("-------------------")
print(header)
print("-------------------")

saved_filename = "/tmp/" + filename
print (saved_filename)
fo = open(saved_filename, "w+b")
fo.write(data)
fo.close()

call(["eog", saved_filename])