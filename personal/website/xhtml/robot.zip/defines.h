 /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                              *
*    defines.h                                                                        *
*                                                                                     *
*  Description:                                                                       *
*    Header file containing all the defined constants.                                *
*    Contains Pin numbers, physical constants and hardware specific constants.        *
*    Contains Chosen constants for filtering purposes.                                *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __DEFINES_H__
#define __DEFINES_H__

#define LED 13

// using interrupts 0 ( 2 ) , 1 ( 3) , 2 ( 21 ) , 3 ( 20)

#define LEFT_PWM_PIN        6
#define LEFT_INPUT2_PIN     41
#define LEFT_INPUT1_PIN     39

#define LEFT_CHANNELA_PIN   20
#define LEFT_CHANNELB_PIN   21

#define RIGHT_PWM_PIN       7
#define RIGHT_INPUT2_PIN    33
#define RIGHT_INPUT1_PIN    31

#define RIGHT_CHANNELA_PIN  2
#define RIGHT_CHANNELB_PIN  3

//Orientation Sensors
#define X_G_PIN     1//gyroscope x value
#define ZERO_G_PIN  2//gyroscope zero value
#define X_A_PIN     0//accelerometer x value

//object detection - read = analog, enable = digital
#define MIDDLE_READ 4
#define LEFT_READ 5
#define RIGHT_READ 3

#define MIDDLE_ENABLE 50
#define LEFT_ENABLE 48
#define RIGHT_ENABLE 52

#define FILTER_LENGTH_MAX 30
#define FILTER_LENGTH_MIN 6
#define SENSOR_SWITCH_TIME 500

//Hubby Wheel I/O
#define LEFT_WHEEL      0
#define RIGHT_WHEEL     1

#define WHEEL_BRAKE     3
#define WHEEL_FORWARD   2
#define WHEEL_BACKWARD  1
#define WHEEL_IDLE      0

#define RADIUS_WHEELS   3
#define SPDR_WIDTH      19.25

//Constants
#define NUM_COUNTS_PER_REV  120
#define WHEEL_SPEED_MAX     255
#define WHEEL_SPEED_MIN     60

#define ZERO_ACC 512  //zero value on accelerometer
#define GYRO_MAX 380

//Communication
#define SERIAL_SPEED 9600

//Physical
#define GRAVITY 9.81

//Sensor States
#define POLL_LEFT      0
#define POLL_MIDDLE    1
#define POLL_RIGHT     2
#define ENABLE_LEFT    3
#define ENABLE_MIDDLE  4
#define ENABLE_RIGHT   5
#define SEND_DATA      6

//ObjectDetectionState
#define OD_NOTHING 0
#define OD_LEFT    1
#define OD_RIGHT   2
#define OD_ALL     3

//Wheel States
#define BALANCE       0
#define MOVE_FORWARD  1
#define MOVE_BACKWARD 2
#define TURN_LEFT     3
#define TURN_RIGHT    4

 /* PI functional model defines */
 #define DONE_NAVIGATING 0
 #define X_WAYPOINT      1
 #define Y_WAYPOINT      2

#endif

