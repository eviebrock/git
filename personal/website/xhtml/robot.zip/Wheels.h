/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                               *
*    Wheels.h                                                                          *
*                                                                                      *
*  Description:                                                                        *
*    Header file controlling the Hubby Wheels                                          *
*    Keeps track of current speed, applies newly calculated speeds and reads           *
*    distance travelled from wheels                                                    *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __WHEELS_H__
#define __WHEELS_H__
/* Variables */
int Wheel_State;

int left_speed;
int right_speed;

int left_channelA;
int left_channelB;
int right_channelA;
int right_channelB;

int leftWheelState;
int rightWheelState;

int leftWheelCount;
int rightWheelCount;

/* Methods */
void initWheels(void);

//Primary
int readFromWheels(int LeftOrRight);
void applyWheelSpeeds();

int writeToWheels_state(int LeftOrRight, int val); // use defines
void writeToWheels_power(int LeftOrRight, int val); // 0-255

void interrupt_left(void);
void interrupt_right(void);
#endif
