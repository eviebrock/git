 /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                              *
*    ObjectDetection.h                                                                *
*                                                                                     *
*  Description:                                                                       *
*    Header file for the Object Detection Sensors                                     *
*    Has global sensor distance variables.                                            *
*    Enables, disables and reads Sonar Sensors                                        *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __COMMUNICATION_H__
#define __COMMUNICATION_H__
/* Variables */
bool paused_by_pi;

int approxRelX;
int approxRelY;

int LED_STATUS;

bool wp_x_set;
bool wp_y_set;

char MessageReceived[6];

long int x_component;
long int y_component;
int char_count;

/* Methods */
void initCommunication();
void getNextWaypoint();
void SendMyAndObjectData();
void sendMyCoordinateX();
void sendMyCoordinateY();
void pausedByPi();
void resumedByPi();

void SerialMessageSend(int _opcode, int data);

void sendObjRelX();
void sendObjRelY();

void checkSerialBuffer();

#endif
