/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                               *
*    ObjectDetection.h                                                                 *
*                                                                                      *
*  Description:                                                                        *
*    Header file for the Object Detection Sensors                                      *
*    Has global sensor distance variables.                                             *
*    Enables, disables and reads Sonar Sensors                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __OBJECT_DETECTION_H__
#define __OBJECT_DETECTION_H__
/* Variables */
float middle_cm;
float left_cm;
float right_cm;

float my_saved_od_waypoint_x;
float my_saved_od_waypoint_y;

unsigned long sensorSwitchDelayTime;
bool initiatedSwitch;

bool object_detected;

int objectDetectionStatus;
int Sensor_State;

/* Methods */
void initObjectDetection();
void resetObjectDetection();

void middleSensorEnable();
void leftSensorEnable();
void rightSensorEnable();

void middleSensorDisable();
void leftSensorDisable();
void rightSensorDisable();

void middleSensorRead();
void leftSensorRead();
void rightSensorRead();

int getObjectDetectionStatus();
void objectDetected();
void falseAlarm();

#endif
