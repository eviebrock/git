/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                               *
*    ObjectDetection.h                                                                 *
*                                                                                      *
*  Description:                                                                        *
*    Header file for the Object Detection Sensors                                      *
*    Has global sensor distance variables.                                             *
*    Enables, disables and reads Sonar Sensors                                         *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#ifdef NOT_DEFINED
#ifndef __PI_FUNCTIONAL_MODEL_H__
#define __PI_FUNCTIONALMODEL_H__
/* Variables */
int waypoint_array_x[5];
int waypoint_array_y[5];
int  current_waypoint_x;
int  current_waypoint_y;

int nav_waypoint_array_x[2];
int nav_waypoint_array_y[2];
int current_nav_waypoint_x;
int current_nav_waypoint_y;

int timesRead;
bool navigating_object;

unsigned long pausedTime;

/* Methods */
void initPiFunctionalModel();

int getNextWaypoint_x_op();
int getNextWaypoint_y_op();
int getNextWaypoint_x_data();
int getNextWaypoint_y_data();

int readFromPi();

void createWaypointsAroundObject(int _my_x, int _my_y, int _rel_x, int _rel_y);

void printArray();
#endif
#endif
