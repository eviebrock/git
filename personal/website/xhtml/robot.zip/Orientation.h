/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                               *
*    Orientaion.h                                                                      *
*                                                                                      *
*  Description:                                                                        *
*    Header File for Gyroscope and Accelerometer related functions and variables       *
*    Reads Accelerometer and Gyroscope                                                 *
*    Updates global variables with these values                                        *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __ORIENTATION_H__
#define __ORIENTATION_H__
/* Variables */
float acceleration;     //accelerometer reading
float angular_velocity; //gyroscope reading

/* Methods */
int readGyro();  //returns an array of 2 ints, x value, z value
int readAccel(); //returns an array of 2 ints, x value, z value

void updateOrientationSensors();
//void printOrientationSensors();
#endif

