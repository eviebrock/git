/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
*  File:                                                                               *
*    Movement.h                                                                        *
*                                                                                      *
*  Description:                                                                        *
*    Header file for calculating the speed to apply to each wheel to                   *
*    keep SPDR balanced and either stay still, move in the desired direction           *
*    or turn to face a desired direction                                               *
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef __MOVEMENT_H__
#define __MOVEMENT_H__
/* Variables */
int printCount_position;

// Current Location
float my_coordinate_x;
float my_coordinate_y;
float my_azimuth_angle;

// Current and Saved Waypoints
float my_waypoints_x[2];
float my_waypoints_y[2];

float my_waypoint_x;
float my_waypoint_y;

int my_current_wp;
float my_saved_waypoint_x;
float my_saved_waypoint_y;



// Offset to make it think its falling over, therefore move in the desired direction
float rotation_offset;
float movement_offset;
float accel_mult;
float gyro_mult;

// Turning
float azimuth_angle_needed;
float angleDiff;
bool must_turn;

//Timer to track time since last update
unsigned long primaryDelayTime; //use a timer to track time since last update

/* Methods */
void initMovement();

//Primary
void updateWheelState();
void updateWheelSpeeds();
void updatePosition();

//Print
//void printPosition();

//Helper
void syncSpeeds();
void calculateTorques();
void limitWheelSpeeds();
void bilateral_turning();

bool speedsSameSign();
float getAngleDiff(float angle1, float angle2);
#endif


