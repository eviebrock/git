// COMP53 Fall 2012
//
// BreakoutGame.cpp
//
// Application control code for Breakout game.

#include "InterAct2D.h"

// Standard Template Library
#include <list>
using namespace std;

// Breakout game objects
#include "Brick.h"
#include "paddle.h"
#include "clock.h"
#include "ball.h"

///////////////////////////////////////////////////////////////////////////
// class Breakout - controller class for game
///////////////////////////////////////////////////////////////////////////

class Breakout
{
public:
	Breakout();
	~Breakout();

	// single public method to respond to all events
	void handleEvent(Event event);

private:
	// level countdown timer
	float remaining_time;

	// game objects
	list<Brick*> bricks;
	Paddle* paddle;
	Clock* clock;
	Ball* ball;

	// game control signals
	bool game_ready;
	bool left_key_pressed;
	bool right_key_pressed;

	// primary event response methods
	void drawGame(Event event);
	void startGame(Event event);
	void updateGame(Event event);
	void processUserInput(Event event);

	// secondary methods for specific tasks
	void draw_background(Event event);
	void draw_clock(Event event);
	void createBricks(Event event);
	void createPaddle(Event event);
	void createClock(Event event);
	void createBall(Event event);
	void detectCollisions(Event event);
	void destroyGame();
};

///////////////////////////////////////////////////////////////////////////
// class Breakout: constructor and destructor
///////////////////////////////////////////////////////////////////////////

Breakout::Breakout()
	: paddle(NULL), clock(NULL), ball(NULL), game_ready(false),
      left_key_pressed(false), right_key_pressed(false)
{ }

Breakout::~Breakout()
{
	destroyGame();
}

///////////////////////////////////////////////////////////////////////////
// class Breakout: public member functions
///////////////////////////////////////////////////////////////////////////

void Breakout::processUserInput(Event event)
{
	if (event.key_pressed && ((event.key == 'z') || (event.key == 'Z')))
		left_key_pressed = true;
	if (event.key_released && ((event.key == 'z') || (event.key == 'Z')))
		left_key_pressed = false;
	if (event.key_pressed && ((event.key == 'x') || (event.key == 'X')))
		right_key_pressed = true;
	if (event.key_released && ((event.key == 'x') || (event.key == 'X')))
		right_key_pressed = false;
}

void Breakout::updateGame(Event event)
{
	// if time has passed, update the world
	float elapsed_time_sec = event.elapsed_time_msec/1000.0f;
	if (elapsed_time_sec > 0.0)
	{
		remaining_time -= elapsed_time_sec;
		if (remaining_time < 0.0) remaining_time = 0.0;
		if (left_key_pressed) paddle->leftThrust();
		if (right_key_pressed) paddle->rightThrust();
		clock->changeTo(remaining_time);

		// update moving objects
		paddle->move(elapsed_time_sec, 0.0f, float(event.screen_width));
		ball->move(elapsed_time_sec);

		detectCollisions(event);
	}
}

void Breakout::startGame(Event event)
{
	// delete any previous game
	destroyGame();

	// reset all game objects
	remaining_time = 300.0;  // 300 seconds = 5 minutes

	// create game objects
	createBricks(event);
	createPaddle(event);
	createClock(event);
	createBall(event);
	game_ready = true;
}

void Breakout::drawGame(Event event)
{
	// clear the game screen
	draw_background(event);
	// draw all objects
	list<Brick*>::iterator brick_iter;
	for (brick_iter = bricks.begin(); brick_iter != bricks.end(); brick_iter++)
		(*brick_iter)->draw();
	paddle->draw();
	clock->draw();
	ball->draw();
}

///////////////////////////////////////////////////////////////////////////
// class Breakout: miscellaneous private member functions
///////////////////////////////////////////////////////////////////////////

void Breakout::detectCollisions(Event event)
{
	float ball_r = ball->getRadius();

	Point ball_pos = ball->getPosition();
	float ball_x = ball_pos.getX();
	float ball_y = ball_pos.getY();
	float ball_min_x = ball_x - ball_r;
	float ball_max_x = ball_x + ball_r;
	float ball_min_y = ball_y - ball_r;
	float ball_max_y = ball_y + ball_r;

	// check for collisions with walls
	if (ball_min_x < 0.0) ball->collision(false, true, false, false);
	if (ball_max_x > event.screen_width) ball->collision(true, false, false, false);
	if (ball_min_y < 0.0) ball->collision(false, false, false, true);
	if (ball_max_y > event.screen_height) ball->collision(false, false, true, false);

	// check for collision with paddle
	float paddle_left, paddle_right, paddle_top, paddle_bottom;
	paddle->getPosition(paddle_left, paddle_right, paddle_top, paddle_bottom);
	if ((ball_x >= paddle_left) && (ball_x <= paddle_right) &&
		(ball_max_y >= paddle_top))
	{
		// invert vertical speed
		ball->collision(false, false, true, false);
		// change horizontal speed based on paddle speed
		ball->addHorizontalSpeed(paddle->getSpeed()*0.1f);
	}

	//check for ball/Brick collisions

	list<Brick*>::iterator brick_iter = bricks.begin();
	while (brick_iter!=bricks.end())
	{
		Brick* brick = (*brick_iter);

		float brick_left, brick_right, brick_top, brick_bottom;
		brick->getPosition(brick_left, brick_right, brick_top, brick_bottom);

		// if ball touches a brick, force it to bounce downward
		if ((ball_x > brick_left) && (ball_x < brick_right) &&
            (ball_y > brick_top) && (ball_y < brick_bottom))
		{
		    ball->collision(false, false, false, true);
		}

		brick_iter++;
	}
}

void Breakout::draw_background(Event event)
{
	// Draw a rectangle to clear the game screen.
	Rect background(Point(event.screen_width/2.0f, event.screen_height/2.0f),
		float(event.screen_width), float(event.screen_height));
	background.draw();
}

///////////////////////////////////////////////////////////////////////////
// class Breakout: private member functions for creating game objects
///////////////////////////////////////////////////////////////////////////

void Breakout::createBricks(Event event)
{
	bricks.clear();

	// create a 10x10 grid of Bricks, evenly spaced
	// across the top half of the screen

	float x_spacing = event.screen_width / 9.0f;
	float y_spacing = event.screen_height / 20.0f;
	float brick_width = x_spacing * 0.95f;
	float brick_height = y_spacing * 0.9f;
	float x, y;

	y = y_spacing;
	for (int row = 0; row < 10; row++)
	{
		x = x_spacing/2.0f;
		for (int column = 0; column < 10; column++)
		{
			Brick* new_brick = new Brick(x, y, brick_width, brick_height, blue);
			bricks.push_back(new_brick);
			x += x_spacing;
		}
		y += y_spacing;
	}

}

void Breakout::createPaddle(Event event)
{
	float x_center = event.screen_width / 2.0f;
	float y_center = event.screen_height - 50.0f;
	float paddle_width = 100.0f;
	float paddle_height = 30.0f;

	paddle = new Paddle(x_center, y_center, paddle_width, paddle_height, purple);
}

void Breakout::createBall(Event event)
{
	float x_center = event.screen_width / 2.0f;
	float y_center = event.screen_height/ 2.0f;
	float ball_size = 10.0f;
	float x_speed = 0.0f;
	float y_speed = 100.0f;

	ball = new Ball(x_center, y_center, ball_size, x_speed, y_speed, green);
}

void Breakout::createClock(Event event)
{
	float x_position = 0.0f;
	float y_position = event.screen_height - 40.0f;

	clock = new Clock(x_position, y_position, remaining_time, yellow, darkgray);
}

void Breakout::destroyGame()
{
	if (clock != NULL) delete clock; clock = NULL;
	if (ball != NULL) delete ball; ball = NULL;
	if (paddle != NULL) delete paddle; paddle = NULL;
	list<Brick*>::iterator brick_iter;
	for (brick_iter = bricks.begin(); brick_iter != bricks.end(); brick_iter++)
		if ((*brick_iter) != NULL) delete (*brick_iter);
	bricks.clear();
	game_ready = false;
}

///////////////////////////////////////////////////////////////////////////
// Global Breakout object that controls the game.
///////////////////////////////////////////////////////////////////////////

Breakout breakout_game;

///////////////////////////////////////////////////////////////////////////
// Callback function from InterAct2D that drives the game.
///////////////////////////////////////////////////////////////////////////

void Breakout::handleEvent(Event event)
{
	if (event.restart) startGame(event);

	// wait for a restart event to initialize the game before
	// processing any other events.
	if (!game_ready) return;

	// these methods check for appropriate events
	// so they should always be called
	breakout_game.processUserInput(event);
	breakout_game.updateGame(event);

	// repaint event means to redraw entire screen
	if (event.repaint) drawGame(event);
}

// call back function just passes event to the game
void handleEvent(Event event)
{
	breakout_game.handleEvent(event);
}
